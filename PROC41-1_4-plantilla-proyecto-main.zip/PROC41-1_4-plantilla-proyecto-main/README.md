# PROC41-1_4-plantilla-proyecto
## Plantilla del proyecto para la clase 41 nivel PRO 1:4.
### Depuración por parte del alumno en tres secciones diferentes.

Nombre en Inglés: project-template-KANGAROO-IN-JUNGLE-1
